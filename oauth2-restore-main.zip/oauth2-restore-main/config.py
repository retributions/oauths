token = ""
oauth2_url = ""
recover_key = ""
guildid = ""
roleid = ""

API_ENDPOINT = "https://discord.com/api/v9" #DONT TOUCH
CLIENT_ID = ""
CLIENT_SECRET = ""
BASE_URL = "http://google.com"
REDIRECT_URI = "http://google.com/callback"
